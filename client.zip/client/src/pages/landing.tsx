import { Button } from "@/components/ui/button";
import { CheckCircle, LayoutDashboard, Users, BarChart3 } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">TaskFlow</span>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-login"
            >
              Log In
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-4 py-20 lg:py-32">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-5xl lg:text-6xl font-bold tracking-tight">
              Manage Projects & Tasks
              <span className="block text-primary mt-2">With Clarity & Speed</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              A powerful collaboration platform that helps teams organize work, track progress, and deliver results faster.
            </p>
            <div className="flex gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-get-started"
                className="text-base px-8"
              >
                Get Started Free
              </Button>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="space-y-3 text-center">
              <div className="h-12 w-12 bg-primary/10 rounded-md flex items-center justify-center mx-auto">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Task Management</h3>
              <p className="text-sm text-muted-foreground">
                Create, assign, and track tasks with priority levels and due dates.
              </p>
            </div>

            <div className="space-y-3 text-center">
              <div className="h-12 w-12 bg-primary/10 rounded-md flex items-center justify-center mx-auto">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Team Collaboration</h3>
              <p className="text-sm text-muted-foreground">
                Work together seamlessly with role-based access and activity tracking.
              </p>
            </div>

            <div className="space-y-3 text-center">
              <div className="h-12 w-12 bg-primary/10 rounded-md flex items-center justify-center mx-auto">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Analytics Dashboard</h3>
              <p className="text-sm text-muted-foreground">
                Visualize progress with charts and metrics that matter to your team.
              </p>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto bg-card border rounded-md p-8 text-center space-y-4">
            <h2 className="text-3xl font-bold">Ready to get organized?</h2>
            <p className="text-muted-foreground">
              Join thousands of teams using TaskFlow to streamline their workflow.
            </p>
            <Button
              size="lg"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-cta-login"
              className="text-base px-8"
            >
              Start Now
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8 mt-16">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 TaskFlow. Built for VITyarthi Academic Project.</p>
        </div>
      </footer>
    </div>
  );
}
