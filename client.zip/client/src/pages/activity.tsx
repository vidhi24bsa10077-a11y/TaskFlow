import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { FolderKanban, CheckSquare, UserPlus, Edit, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { ActivityWithUser } from "@shared/schema";

const getActivityIcon = (action: string) => {
  if (action.includes("project")) return FolderKanban;
  if (action.includes("task")) return CheckSquare;
  if (action.includes("member")) return UserPlus;
  if (action.includes("update")) return Edit;
  if (action.includes("delete")) return Trash2;
  return CheckSquare;
};

const getActivityColor = (action: string) => {
  if (action.includes("create")) return "text-chart-2";
  if (action.includes("update")) return "text-chart-1";
  if (action.includes("delete")) return "text-chart-5";
  return "text-muted-foreground";
};

export default function Activity() {
  const { data: activities, isLoading } = useQuery<ActivityWithUser[]>({
    queryKey: ["/api/activities"],
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="space-y-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex gap-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Activity Feed</h1>
        <p className="text-muted-foreground mt-1">Recent actions and updates across your projects</p>
      </div>

      {!activities?.length ? (
        <Card className="text-center py-12">
          <CardContent>
            <div className="h-12 w-12 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
              <CheckSquare className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No activity yet</h3>
            <p className="text-sm text-muted-foreground">
              Activity from your projects and tasks will appear here
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-1">
          {activities.map((activity) => {
            const Icon = getActivityIcon(activity.action);
            const colorClass = getActivityColor(activity.action);
            const initials = activity.user.firstName && activity.user.lastName
              ? `${activity.user.firstName[0]}${activity.user.lastName[0]}`.toUpperCase()
              : activity.user.email?.[0]?.toUpperCase() || "U";
            
            return (
              <Card key={activity.id} className="hover-elevate" data-testid={`activity-${activity.id}`}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={activity.user.profileImageUrl || undefined} className="object-cover" />
                      <AvatarFallback>{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <Icon className={`h-4 w-4 shrink-0 ${colorClass}`} />
                        <p className="text-sm">
                          <span className="font-medium">
                            {activity.user.firstName || activity.user.email}
                          </span>
                          {" "}
                          <span className="text-muted-foreground">
                            {activity.action}
                          </span>
                        </p>
                      </div>
                      {activity.metadata && typeof activity.metadata === "object" && "name" in activity.metadata && activity.metadata.name && (
                        <p className="text-sm text-muted-foreground truncate">
                          {String(activity.metadata.name)}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
