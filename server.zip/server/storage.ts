// Reference: blueprint:javascript_database and blueprint:javascript_log_in_with_replit
import {
  users,
  projects,
  tasks,
  activities,
  projectMembers,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type UpdateProject,
  type Task,
  type InsertTask,
  type UpdateTask,
  type Activity,
  type InsertActivity,
  type ProjectMember,
  type InsertProjectMember,
  type ProjectWithOwner,
  type TaskWithRelations,
  type ActivityWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Project operations
  getProjects(userId: string): Promise<ProjectWithOwner[]>;
  getProject(id: string): Promise<ProjectWithOwner | undefined>;
  createProject(project: InsertProject, userId: string): Promise<Project>;
  updateProject(id: string, project: UpdateProject): Promise<Project | undefined>;
  deleteProject(id: string): Promise<void>;

  // Task operations
  getTasks(userId: string): Promise<TaskWithRelations[]>;
  getTasksByProject(projectId: string): Promise<TaskWithRelations[]>;
  getTask(id: string): Promise<TaskWithRelations | undefined>;
  createTask(task: InsertTask, userId: string): Promise<Task>;
  updateTask(id: string, task: UpdateTask): Promise<Task | undefined>;
  deleteTask(id: string): Promise<void>;

  // Project member operations
  addProjectMember(member: InsertProjectMember): Promise<ProjectMember>;
  removeProjectMember(projectId: string, userId: string): Promise<void>;

  // Activity operations
  getActivities(limit?: number): Promise<ActivityWithUser[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Dashboard stats
  getDashboardStats(userId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getProjects(userId: string): Promise<ProjectWithOwner[]> {
    const result = await db.query.projects.findMany({
      where: eq(projects.ownerId, userId),
      with: {
        owner: true,
        members: {
          with: {
            user: true,
          },
        },
      },
      orderBy: [desc(projects.updatedAt)],
    });

    // Get task counts for each project
    const projectsWithCounts = await Promise.all(
      result.map(async (project) => {
        const [taskCount] = await db
          .select({ count: count() })
          .from(tasks)
          .where(eq(tasks.projectId, project.id));
        
        return {
          ...project,
          _count: {
            tasks: taskCount.count,
          },
        };
      })
    );

    return projectsWithCounts;
  }

  async getProject(id: string): Promise<ProjectWithOwner | undefined> {
    const project = await db.query.projects.findFirst({
      where: eq(projects.id, id),
      with: {
        owner: true,
        members: {
          with: {
            user: true,
          },
        },
      },
    });

    if (!project) return undefined;

    const [taskCount] = await db
      .select({ count: count() })
      .from(tasks)
      .where(eq(tasks.projectId, id));

    return {
      ...project,
      _count: {
        tasks: taskCount.count,
      },
    };
  }

  async createProject(projectData: InsertProject, userId: string): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values({
        ...projectData,
        ownerId: userId,
      })
      .returning();
    return project;
  }

  async updateProject(id: string, projectData: UpdateProject): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({
        ...projectData,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // Task operations
  async getTasks(userId: string): Promise<TaskWithRelations[]> {
    const result = await db.query.tasks.findMany({
      where: eq(tasks.createdById, userId),
      with: {
        project: true,
        assignee: true,
        createdBy: true,
      },
      orderBy: [desc(tasks.createdAt)],
    });
    return result;
  }

  async getTasksByProject(projectId: string): Promise<TaskWithRelations[]> {
    const result = await db.query.tasks.findMany({
      where: eq(tasks.projectId, projectId),
      with: {
        project: true,
        assignee: true,
        createdBy: true,
      },
      orderBy: [desc(tasks.createdAt)],
    });
    return result;
  }

  async getTask(id: string): Promise<TaskWithRelations | undefined> {
    const task = await db.query.tasks.findFirst({
      where: eq(tasks.id, id),
      with: {
        project: true,
        assignee: true,
        createdBy: true,
      },
    });
    return task;
  }

  async createTask(taskData: InsertTask, userId: string): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values({
        ...taskData,
        createdById: userId,
      })
      .returning();
    return task;
  }

  async updateTask(id: string, taskData: UpdateTask): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set({
        ...taskData,
        updatedAt: new Date(),
      })
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  // Project member operations
  async addProjectMember(memberData: InsertProjectMember): Promise<ProjectMember> {
    const [member] = await db
      .insert(projectMembers)
      .values(memberData)
      .returning();
    return member;
  }

  async removeProjectMember(projectId: string, userId: string): Promise<void> {
    await db
      .delete(projectMembers)
      .where(
        and(
          eq(projectMembers.projectId, projectId),
          eq(projectMembers.userId, userId)
        )
      );
  }

  // Activity operations
  async getActivities(limit: number = 50): Promise<ActivityWithUser[]> {
    const result = await db.query.activities.findMany({
      with: {
        user: true,
      },
      orderBy: [desc(activities.createdAt)],
      limit,
    });
    return result;
  }

  async createActivity(activityData: InsertActivity): Promise<Activity> {
    const [activity] = await db
      .insert(activities)
      .values(activityData)
      .returning();
    return activity;
  }

  // Dashboard stats
  async getDashboardStats(userId: string): Promise<any> {
    // Get all projects owned by user
    const userProjects = await db
      .select()
      .from(projects)
      .where(eq(projects.ownerId, userId));

    const totalProjects = userProjects.length;
    const activeProjects = userProjects.filter(p => p.status === "active").length;

    // Get all tasks created by user
    const userTasks = await db
      .select()
      .from(tasks)
      .where(eq(tasks.createdById, userId));

    const totalTasks = userTasks.length;
    const completedTasks = userTasks.filter(t => t.status === "completed").length;
    const inProgressTasks = userTasks.filter(t => t.status === "in_progress").length;
    const overdueTasks = userTasks.filter(
      t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== "completed"
    ).length;

    // Task statistics by status
    const tasksByStatus = [
      { name: "To Do", value: userTasks.filter(t => t.status === "todo").length },
      { name: "In Progress", value: inProgressTasks },
      { name: "In Review", value: userTasks.filter(t => t.status === "in_review").length },
      { name: "Completed", value: completedTasks },
      { name: "Blocked", value: userTasks.filter(t => t.status === "blocked").length },
    ];

    // Task statistics by priority
    const tasksByPriority = [
      { name: "Low", value: userTasks.filter(t => t.priority === "low").length },
      { name: "Medium", value: userTasks.filter(t => t.priority === "medium").length },
      { name: "High", value: userTasks.filter(t => t.priority === "high").length },
      { name: "Urgent", value: userTasks.filter(t => t.priority === "urgent").length },
    ];

    // Recent projects
    const recentProjects = userProjects.slice(0, 5);

    // Recent tasks
    const recentTasks = userTasks
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);

    return {
      totalProjects,
      activeProjects,
      totalTasks,
      completedTasks,
      inProgressTasks,
      overduerTasks: overdueTasks,
      tasksByStatus,
      tasksByPriority,
      recentProjects,
      recentTasks,
    };
  }
}

export const storage = new DatabaseStorage();
